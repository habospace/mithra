use std::collections::BTreeMap;

use crate::data::ClosureParser;
use crate::data::FnParser;
use crate::data::Function;
use crate::data::MithraError;
use crate::data::MithraVal;
use crate::data::Text;

use crate::primitive_parsers::any_string;
use crate::primitive_parsers::char;
use crate::primitive_parsers::chars_to_float;
use crate::primitive_parsers::chars_to_int;
use crate::primitive_parsers::numeric_chars;
use crate::primitive_parsers::skip_many;
use crate::primitive_parsers::string;
use crate::primitive_parsers::word;

use crate::parser_combinators::combine;
use crate::parser_combinators::many;
use crate::parser_combinators::sep_by;

type FnMithraParser = FnParser<MithraVal>;
type ClosureMithraParser = ClosureParser<MithraVal>;

fn parse_null(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    string(String::from("None").chars().collect())(text)?;
    Ok(MithraVal::Null)
}

fn parse_bool(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let true_chars = String::from("True").chars().collect();
    let _true = string(true_chars)(text);
    if _true.is_ok() {
        return Ok(MithraVal::Bool(true));
    }
    let false_chars = String::from("False").chars().collect();
    string(false_chars)(text)?;
    Ok(MithraVal::Bool(false))
}

fn parse_int(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let int_chars = numeric_chars(text)?;
    Ok(MithraVal::Int(chars_to_int(int_chars)?))
}

fn parse_float(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let mut integer_part = numeric_chars(text)?;
    parse_char('.')(text)?;
    let fractional_part = numeric_chars(text)?;
    integer_part.extend(vec!['.']);
    integer_part.extend(fractional_part);
    Ok(MithraVal::Float(chars_to_float(integer_part)?))
}

fn parse_char(c: char) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        // may need to optionally set failure pointer
        let char = char(c)(text)?;
        Ok(MithraVal::Char(char))
    })
}

fn parse_atom(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let atom = word(text)?;
    Ok(MithraVal::Atomic(atom))
}

fn parse_string(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let string = any_string(text)?;
    Ok(MithraVal::String(string))
}

pub fn skip_spaces() -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        skip_many(vec![' '])(text)?;
        Ok(MithraVal::Null)
    })
}

fn inline_expr() -> ClosureParser<MithraVal> {
    fn first_non_null(items: &mut Vec<MithraVal>) -> MithraVal {
        loop {
            match items.pop() {
                Some(MithraVal::Null) => {}
                Some(non_null) => return non_null,
                None => break,
            }
        }
        MithraVal::Null
    }
    combine(
        vec![skip_spaces(), Box::new(parse_expr), skip_spaces()],
        first_non_null,
    )
}

fn comma_sep_exprs() -> ClosureParser<Vec<MithraVal>> {
    sep_by(inline_expr(), parse_char(','))
}

fn inline_word() -> ClosureParser<String> {
    fn first_non_empty_string(items: &mut Vec<String>) -> String {
        loop {
            match items.pop() {
                Some(word) => {
                    if word.len() > 0 {
                        return word;
                    }
                }
                None => break,
            }
        }
        String::from("")
    }
    combine(
        vec![skip_many(vec![' ']), Box::new(word), skip_many(vec![' '])],
        first_non_empty_string,
    )
}

fn comma_sep_words() -> ClosureParser<Vec<String>> {
    sep_by(inline_word(), parse_char(','))
}

fn parse_function_call(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let function_name = word(text)?;
    skip_spaces()(text)?;
    parse_char('(')(text)?;
    let args = comma_sep_exprs()(text)?;
    parse_char(')')(text).map_err(|_| {
        MithraError::ParseError(format!(
            "missing ')' for '{}' function call (line: {}, char: {}).",
            function_name,
            text.line_num(),
            text.char_pos()
        ))
    })?;
    Ok(MithraVal::List(vec![
        MithraVal::Atomic(function_name),
        MithraVal::List(args),
    ]))
}

fn parse_list(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    parse_char('[')(text)?;
    let exprs = comma_sep_exprs()(text)?;
    parse_char(']')(text).map_err(|_| {
        MithraError::ParseError(format!(
            "unterminated list, missing ']' (line: {}, char: {}).",
            text.line_num(),
            text.char_pos()
        ))
    })?;
    Ok(MithraVal::List(exprs))
}

fn parse_dict(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();

    fn parse_kv_pair(text: &mut Text) -> Result<(String, MithraVal), MithraError> {
        skip_spaces()(text)?;
        let key = any_string(text)?;
        skip_spaces()(text)?;
        parse_char(':')(text)?;
        skip_spaces()(text)?;
        let value = parse_expr(text)?;
        skip_spaces()(text)?;
        return Ok((key, value));
    }

    parse_char('{')(text)?;
    let mut kv_pairs = sep_by(Box::new(parse_kv_pair), parse_char(','))(text)?;
    parse_char('}')(text).map_err(|_| {
        MithraError::ParseError(format!(
            "unterminated dict, missing '}}' (line: {}, char: {}).",
            text.line_num(),
            text.char_pos()
        ))
    })?;
    let mut dictionary = BTreeMap::new();
    loop {
        match kv_pairs.pop() {
            Some(kv_pair) => {
                dictionary.insert(kv_pair.0, kv_pair.1);
            }
            None => break,
        }
    }
    Ok(MithraVal::Dict(dictionary))
}

fn first_parse_error_or_default(errors: Vec<MithraError>, default: MithraError) -> MithraError {
    for error in errors {
        match error {
            MithraError::ParseError(err) => {
                return MithraError::ParseError(err);
            }
            _ => {}
        }
    }
    default
}

fn parse_expr(text: &mut Text) -> Result<MithraVal, MithraError> {
    let mut errors = Vec::new();
    let parsers: [FnMithraParser; 9] = [
        parse_function_call,
        parse_list,
        parse_dict,
        parse_bool,
        parse_float,
        parse_int,
        parse_null,
        parse_string,
        parse_atom,
    ];
    for parser in &parsers {
        let result = parser(text);
        match result {
            Ok(mithra_val) => {
                return Ok(mithra_val);
            }
            Err(mithra_err) => errors.push(mithra_err),
        }
    }
    Err(first_parse_error_or_default(
        errors,
        MithraError::ParseError(format!(
            "couldn't parse an expression (line: {}, char: {}).",
            text.line_num(),
            text.char_pos()
        )),
    ))
}

fn parse_return_statement(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let return_chars = String::from("return").chars().collect();
    let return_parsed = string(return_chars)(text)?;
    skip_spaces()(text)?;
    let expr = parse_expr(text).map_err(|_| {
        MithraError::ParseError(format!(
            "'return' has to be followed by an expression (line: {}, char: {}).",
            text.line_num(),
            text.char_pos()
        ))
    })?;
    Ok(MithraVal::List(vec![
        MithraVal::String(return_parsed),
        expr,
    ]))
}

pub fn parse_assignment(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let varname = parse_atom(text)?;
    skip_spaces()(text)?;
    parse_char('=')(text)?;
    skip_spaces()(text)?;
    let expr = parse_expr(text).map_err(|_| {
        MithraError::ParseError(format!(
            "'=' has to be followed by an expression in assignment (line: {}, char: {}).",
            text.line_num(),
            text.char_pos()
        ))
    })?;
    Ok(MithraVal::List(vec![
        varname,
        MithraVal::Atomic(String::from("=")),
        expr,
    ]))
}

fn parse_empty_line(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    skip_spaces()(text)?;
    parse_char('\n')(text)?;
    Ok(MithraVal::Null)
}

fn parse_indentation(i: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();
        let indent_chars = match i {
            0 => Vec::new(),
            _ => {
                let spaces: String = std::iter::repeat(' ').take(i * 4).collect();
                spaces.chars().collect()
            }
        };
        string(indent_chars)(text).map_err(|_| {
            MithraError::ParseError(format!(
                "incorrect indentation (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            ))
        })?;
        Ok(MithraVal::Null)
    })
}

fn parse_inline_expr(indent: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();

        if parse_empty_line(text).is_ok() {
            return Ok(MithraVal::Null);
        }

        parse_indentation(indent)(text)?;
        let mut errors = Vec::new();

        // single line expressions
        let fn_parsers: [FnMithraParser; 3] =
            [parse_return_statement, parse_assignment, parse_expr];
        for parser in &fn_parsers {
            let result = parser(text);
            match result {
                Ok(mithra_val) => {
                    skip_spaces()(text)?;

                    parse_char('\n')(text)?;
                    return Ok(mithra_val);
                }
                Err(mithra_err) => errors.push(mithra_err),
            }
        }
        // multi line expressions
        let closure_parsers: [ClosureMithraParser; 2] =
            [parse_if_else_block(indent), parse_function(indent)];
        for parser in &closure_parsers {
            let result = parser(text);
            match result {
                Ok(mithra_val) => {
                    return Ok(mithra_val);
                }
                Err(mithra_err) => errors.push(mithra_err),
            }
        }
        Err(first_parse_error_or_default(
            errors,
            MithraError::ParseError(format!(
                "couldn't parse an expression (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            )),
        ))
    })
}

pub fn parse_inline_exprs(indent: usize, error_on_failure: bool) -> ClosureParser<Vec<MithraVal>> {
    Box::new(
        move |text: &mut Text| -> Result<Vec<MithraVal>, MithraError> {
            many(parse_inline_expr(indent), error_on_failure)(text)
        },
    )
}

pub fn parse_if_else_block(indent: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();

        // try parsing 'if' block

        // parse 'if'
        let if_chars = String::from("if").chars().collect();
        string(if_chars)(text)?;

        parse_char(' ')(text)?;
        skip_spaces()(text)?;

        // parse predicate
        let predicate = parse_expr(text).map_err(|_| {
            MithraError::ParseError(format!(
                "'if' has to be followed by predicate expression (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            ))
        })?;

        skip_spaces()(text)?;

        // parse ':' in 'if predicate_expr:'
        parse_char(':')(text).map_err(|_| {
            MithraError::ParseError(format!(
                "predicate in 'if' block has to be followed by ':' (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            ))
        })?;

        skip_spaces()(text)?;
        parse_char('\n')(text)?;

        // parse 'if' expressions
        let if_exprs = parse_inline_exprs(indent + 1, false)(text)?;
        if if_exprs.is_empty() {
            return Err(MithraError::ParseError(format!(
                "empty 'if' block (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            )));
        }

        let mut if_else_block_parsed = vec![
            MithraVal::Atomic(String::from("if")),
            predicate,
            MithraVal::List(if_exprs),
        ];

        // try parsing 'else' block, if it doesn't exist just return 'if' block

        //parse 'else:'
        parse_indentation(indent)(text)?;
        let else_chars = String::from("else").chars().collect();
        let else_parsed = string(else_chars)(text);
        if else_parsed.is_err() {
            return Ok(MithraVal::List(if_else_block_parsed));
        }

        skip_spaces()(text)?;
        parse_char(':')(text).map_err(|_| {
            MithraError::ParseError(format!(
                "'else' has to be followed by ':' (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            ))
        })?;

        skip_spaces()(text)?;
        parse_char('\n')(text)?;

        // parse 'else' expressions
        let else_exprs = parse_inline_exprs(indent + 1, false)(text)?;
        if else_exprs.is_empty() {
            return Err(MithraError::ParseError(format!(
                "empty 'else' block (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            )));
        }

        if_else_block_parsed.push(MithraVal::Atomic(String::from("else")));
        if_else_block_parsed.push(MithraVal::List(else_exprs));
        Ok(MithraVal::List(if_else_block_parsed))
    })
}

pub fn parse_function(indent: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();

        // parse 'def'
        let def_chars = String::from("def").chars().collect();
        string(def_chars)(text)?;

        // parse function name
        parse_char(' ')(text)?;
        skip_spaces()(text)?;
        let function_name = word(text).map_err(|_| {
            MithraError::ParseError(format!(
                "'def' has to be followed by valid function name (line: {}, char: {}).",
                text.line_num(),
                text.char_pos()
            ))
        })?;
        skip_spaces()(text)?;

        // parse args
        parse_char('(')(text)?;
        let args = comma_sep_words()(text)?;
        parse_char(')')(text)?;

        parse_char(':')(text)?;
        skip_spaces()(text)?;
        parse_char('\n')(text)?;

        // parse function body
        let exprs = parse_inline_exprs(indent + 1, false)(text)?;

        let function = Function {
            name: function_name,
            params: args,
            body: exprs,
        };
        Ok(MithraVal::Function(function))
    })
}
