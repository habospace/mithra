use std::collections::BTreeMap;
use std::error;
use std::fmt;
use std::usize;

type Pointer = usize;
type LineNum = usize;
type CharPos = usize;

#[derive(Debug, Clone)]
pub struct Function {
    pub name: String,
    pub params: Vec<String>,
    pub body: Vec<MithraVal>,
}

#[repr(C)]
#[derive(Debug, Clone)]
pub enum MithraVal {
    Null,
    Atomic(String),
    List(Vec<MithraVal>),
    Dict(BTreeMap<String, MithraVal>),
    Int(i64),
    Float(f64),
    String(String),
    Char(char),
    Bool(bool),
    Function(Function),
}

#[derive(Debug)]
pub enum MithraError {
    NothingParsed,
    ParseError(String),
    RuntimeError(String),
}

impl fmt::Display for MithraError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            MithraError::NothingParsed => write!(f, "NothingParsedError"),
            MithraError::ParseError(message) => write!(f, "ParseError: {}", message),
            MithraError::RuntimeError(message) => write!(f, "RuntimeError: {}", message),
        }
    }
}

impl error::Error for MithraError {}

#[derive(Debug)]
pub struct Text {
    pub chars: Vec<char>,
    pub pointer: Pointer,
    pub failure_pointer: Option<Pointer>,
    pub pointer_char_pos_map: BTreeMap<Pointer, (LineNum, CharPos)>,
}

impl Text {
    pub fn new(chars: Vec<char>) -> Text {
        let mut line_num: LineNum = 1;
        let mut char_pos: CharPos = 1;
        let mut pointer_char_pos_map = BTreeMap::new();
        for (i, &c) in chars.iter().enumerate() {
            if c == '\n' {
                line_num += 1;
                char_pos = 1;
                continue;
            }
            pointer_char_pos_map.insert(i, (line_num, char_pos));
            char_pos += 1;
        }
        Text {
            chars: chars,
            pointer: 0,
            failure_pointer: None,
            pointer_char_pos_map: pointer_char_pos_map,
        }
    }

    pub fn get_next(&self) -> Option<char> {
        match self.chars.get(self.pointer) {
            Some(char) => Some(*char),
            None => None,
        }
    }

    pub fn incr_pointer(&mut self) {
        self.pointer += 1
    }

    pub fn set_failure_pointer(&mut self) {
        self.failure_pointer = Some(self.pointer)
    }

    pub fn jump_back(&mut self) {
        match self.failure_pointer {
            Some(failure_pointer) => {
                self.pointer = failure_pointer;
                self.failure_pointer = None;
            }
            None => {}
        }
    }

    fn get_line_num_char_pos(&self) -> (LineNum, CharPos) {
        match self.pointer_char_pos_map.get(&self.pointer) {
            Some(x) => *x,
            None => (0, 0),
        }
    }

    pub fn line_num(&self) -> LineNum {
        self.get_line_num_char_pos().0
    }

    pub fn char_pos(&self) -> CharPos {
        self.get_line_num_char_pos().1
    }
}

pub type FnParser<T> = fn(&mut Text) -> Result<T, MithraError>;
pub type ClosureParser<T> = Box<dyn Fn(&mut Text) -> Result<T, MithraError>>;
