use crate::data::InlinePointer;
use crate::data::LineNum;
use crate::data::MithraError;

// 'ParseError's

pub fn generic_parse_error(line_num: LineNum, inline_position: InlinePointer) -> MithraError {
    MithraError::ParseError(format!(
        "couldn't parse an expression (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn no_expr_in_function_err(
    func_name: &String,
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "function '{}' must have at least one expression (line: {}, char: {}).",
        func_name, line_num, inline_position
    ))
}

pub fn unterminated_func_call_err(
    func_name: &String,
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "missing ')' for '{}' function call (line: {}, char: {}).",
        func_name, line_num, inline_position
    ))
}

pub fn unterminated_list_err(line_num: LineNum, inline_position: InlinePointer) -> MithraError {
    MithraError::ParseError(format!(
        "unterminated list, missing ']' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn unterminated_dictionary_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "unterminated dict, missing '}}' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_return_expr_err(line_num: LineNum, inline_position: InlinePointer) -> MithraError {
    MithraError::ParseError(format!(
        "'return' has to be followed by an expression (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_assignment_expr_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "'=' has to be followed by an expression in assignment (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn indentation_err(
    indent: usize,
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "incorrect indentation, expected_level: {} (line: {}, char: {}).",
        indent, line_num, inline_position
    ))
}

pub fn missing_predicate_expr_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "'if' has to be followed by predicate expression (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_colon_after_predicate_expr_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "predicate expression in 'if' block has to be followed by ':' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_mandatory_if_expr_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "'if' block must have at least one expression (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_colon_after_else_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "'else' has to be followed by ':' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_mandatory_else_expr_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "'else' block must have at least one expression (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_function_name_err(line_num: LineNum, inline_position: InlinePointer) -> MithraError {
    MithraError::ParseError(format!(
        "'def' has to be followed by valid function name (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_open_parenthesis_before_func_args_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "function name has to be followed by '(' eg. '(...' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_function_args_err(line_num: LineNum, inline_position: InlinePointer) -> MithraError {
    MithraError::ParseError(format!(
        "function name has to be followed by args eg. '(arg1, arg2, ...' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_close_parenthesis_before_func_args_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "function args have to be closed by ')' eg. 'arg2, arg3)' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn missing_colon_in_function_definition_line_err(
    line_num: LineNum,
    inline_position: InlinePointer,
) -> MithraError {
    MithraError::ParseError(format!(
        "function args have to be followed by ':' (line: {}, char: {}).",
        line_num, inline_position
    ))
}

pub fn unnecessary_sep_char_err(line_num: LineNum, inline_position: InlinePointer) -> MithraError {
    MithraError::ParseError(format!(
        "unnecessary ',' (line: {}, char: {}).",
        line_num, inline_position
    ))
}
