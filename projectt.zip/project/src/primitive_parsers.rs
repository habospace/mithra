use crate::data::MithraError;
use crate::data::Text;
use lazy_static::lazy_static;

lazy_static! {
    static ref RESERVED_WORDS: Vec<String> = vec![
        String::from("else"),
        String::from("if"),
        String::from("return"),
        String::from("def"),
        String::from("None"),
        String::from("True"),
        String::from("False"),
    ];
}

// parser helpers: 'chars_to_int', 'chars_to_float'

pub fn chars_to_int(chars: Vec<char>) -> Result<i64, MithraError> {
    let string: String = chars.into_iter().collect();
    match string.as_str().parse::<i64>() {
        Ok(f) => {
            return Ok(f);
        }
        Err(_) => return Err(MithraError::NothingParsed),
    }
}

pub fn chars_to_float(chars: Vec<char>) -> Result<f64, MithraError> {
    let string: String = chars.into_iter().collect();
    match string.as_str().parse::<f64>() {
        Ok(f) => {
            return Ok(f);
        }
        Err(_) => return Err(MithraError::NothingParsed),
    }
}

// parsers: 'char', 'stop_at', 'any_string', 'word', 'string', 'numeric_chars'

pub fn char(c: char) -> Box<dyn Fn(&mut Text) -> Result<char, MithraError>> {
    Box::new(move |text: &mut Text| -> Result<char, MithraError> {
        match text.get_next() {
            Some(next_char) => {
                if c == next_char {
                    text.incr_pointer();
                    return Ok(c);
                }
            }
            None => {
                return Err(MithraError::TextConsumed);
            }
        }
        text.jump_back();
        Err(MithraError::NothingParsed)
    })
}

pub fn stop_at(stop_chars: Vec<char>) -> Box<dyn Fn(&mut Text) -> Result<String, MithraError>> {
    Box::new(move |text: &mut Text| -> Result<String, MithraError> {
        let mut parsed_string: String = String::new();
        loop {
            match text.get_next() {
                Some(c) => {
                    if stop_chars.contains(&c) {
                        text.incr_pointer();
                        return Ok(parsed_string);
                    // may need to make a case to break at newline
                    } else {
                        parsed_string.push(c);
                        text.incr_pointer()
                    }
                }
                None => {
                    return Err(MithraError::TextConsumed);
                }
            }
        }
        //text.jump_back();
        //Err(MithraError::NothingParsed)
    })
}

pub fn any_string(text: &mut Text) -> Result<String, MithraError> {
    char('"')(text)?;
    let string = stop_at(vec!['"'])(text);
    if string.is_err() {
        return Err(MithraError::ParseError(format!(
            "Unterminated '\"' (line: {}, char: {}).",
            text.line_num(),
            text.inline_position()
        )));
    }
    Ok(string.unwrap())
}

pub fn word(text: &mut Text) -> Result<String, MithraError> {
    let mut parsed = String::new();
    loop {
        match text.get_next() {
            Some(next_char) => {
                if '_' == next_char || next_char.is_alphabetic() {
                    parsed.push(next_char);
                    text.incr_pointer();
                } else {
                    break;
                }
            }
            None => break,
        }
    }
    if parsed.is_empty() {
        match text.get_next() {
            None => Err(MithraError::TextConsumed),
            Some(_) => {
                text.jump_back();
                Err(MithraError::NothingParsed)
            }
        }
    } else if RESERVED_WORDS.contains(&parsed) {
        text.jump_back();
        Err(MithraError::ParseError(format!(
            "Can't use '{}' it's a reserved word (line: {}, char: {}).",
            parsed,
            text.line_num(),
            text.inline_position()
        )))
    } else {
        Ok(parsed)
    }
}

pub fn string(string_chars: Vec<char>) -> Box<dyn Fn(&mut Text) -> Result<String, MithraError>> {
    Box::new(move |text: &mut Text| -> Result<String, MithraError> {
        //if text.failure_pointer.is_none() {
        //    text.set_failure_pointer()
        //}
        let mut string_pointer: usize = 0;
        let mut parsed_string: String = String::new();
        loop {
            let next_string_char: Option<&char> = string_chars.get(string_pointer);
            if next_string_char.is_none() {
                return Ok(parsed_string);
            }
            match text.get_next() {
                Some(next_char) => {
                    if *next_string_char.unwrap() == next_char {
                        parsed_string.push(next_char);
                        string_pointer += 1;
                        text.incr_pointer()
                    } else {
                        break;
                    }
                }
                None => {
                    return Err(MithraError::TextConsumed);
                }
            }
        }
        text.jump_back();
        Err(MithraError::NothingParsed)
    })
}

pub fn numeric_chars(text: &mut Text) -> Result<Vec<char>, MithraError> {
    let mut numerics: Vec<char> = Vec::new();
    loop {
        match text.get_next() {
            Some(next_char) => {
                if next_char.is_numeric() {
                    numerics.push(next_char);
                    text.incr_pointer()
                } else {
                    break;
                }
            }
            None => break,
        }
    }
    if numerics.is_empty() {
        match text.get_next() {
            None => Err(MithraError::TextConsumed),
            Some(_) => {
                text.jump_back();
                Err(MithraError::NothingParsed)
            }
        }
    } else {
        Ok(numerics)
    }
}

pub fn skip_many(skip_chars: Vec<char>) -> Box<dyn Fn(&mut Text) -> Result<String, MithraError>> {
    Box::new(move |text: &mut Text| -> Result<String, MithraError> {
        loop {
            match text.get_next() {
                Some(next_char) => {
                    if skip_chars.contains(&next_char) {
                        text.incr_pointer()
                    } else {
                        break;
                    }
                }
                None => break,
            }
        }
        Ok(String::from(""))
    })
}
