use std::collections::BTreeMap;

use crate::data::ClosureParser;
use crate::data::FnParser;
use crate::data::Function;
use crate::data::MithraError;
use crate::data::MithraVal;
use crate::data::Text;

use crate::errors::generic_parse_error;
use crate::errors::indentation_err;
use crate::errors::missing_assignment_expr_err;
use crate::errors::missing_colon_after_else_err;
use crate::errors::missing_colon_after_predicate_expr_err;
use crate::errors::missing_mandatory_else_expr_err;
use crate::errors::missing_mandatory_if_expr_err;
use crate::errors::missing_predicate_expr_err;
use crate::errors::missing_return_expr_err;
use crate::errors::no_expr_in_function_err;
use crate::errors::unterminated_dictionary_err;
use crate::errors::unterminated_func_call_err;
use crate::errors::unterminated_list_err;

use crate::errors::missing_close_parenthesis_before_func_args_err;
use crate::errors::missing_colon_in_function_definition_line_err;
use crate::errors::missing_function_args_err;
use crate::errors::missing_function_name_err;
use crate::errors::missing_open_parenthesis_before_func_args_err;

use crate::primitive_parsers::any_string;
use crate::primitive_parsers::char;
use crate::primitive_parsers::chars_to_float;
use crate::primitive_parsers::chars_to_int;
use crate::primitive_parsers::numeric_chars;
use crate::primitive_parsers::skip_many;
use crate::primitive_parsers::string;
use crate::primitive_parsers::word;

use crate::parser_combinators::combine;
use crate::parser_combinators::many;
use crate::parser_combinators::sep_by;

type FnMithraParser = FnParser<MithraVal>;
type ClosureMithraParser = ClosureParser<MithraVal>;

fn parse_null(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    string(String::from("None").chars().collect())(text)?;
    Ok(MithraVal::Null)
}

fn parse_bool(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let true_chars = String::from("True").chars().collect();
    let _true = string(true_chars)(text);
    if _true.is_ok() {
        return Ok(MithraVal::Bool(true));
    }
    let false_chars = String::from("False").chars().collect();
    string(false_chars)(text)?;
    Ok(MithraVal::Bool(false))
}

fn parse_int(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let int_chars = numeric_chars(text)?;
    Ok(MithraVal::Int(chars_to_int(int_chars)?))
}

fn parse_float(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let mut integer_part = numeric_chars(text)?;
    parse_char('.')(text)?;
    let fractional_part = numeric_chars(text)?;
    integer_part.extend(vec!['.']);
    integer_part.extend(fractional_part);
    Ok(MithraVal::Float(chars_to_float(integer_part)?))
}

fn parse_char(c: char) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        // may need to optionally set failure pointer
        let char = char(c)(text)?;
        Ok(MithraVal::Char(char))
    })
}

fn parse_atom(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let atom = word(text)?;
    Ok(MithraVal::Atomic(atom))
}

fn parse_string(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let string = any_string(text)?;
    Ok(MithraVal::String(string))
}

pub fn skip_spaces() -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        skip_many(vec![' '])(text)?;
        Ok(MithraVal::Null)
    })
}

fn inline_expr() -> ClosureParser<MithraVal> {
    fn first_non_null(items: &mut Vec<MithraVal>) -> MithraVal {
        loop {
            match items.pop() {
                Some(MithraVal::Null) => {}
                Some(non_null) => return non_null,
                None => break,
            }
        }
        MithraVal::Null
    }
    combine(
        vec![skip_spaces(), Box::new(parse_expr), skip_spaces()],
        first_non_null,
    )
}

fn comma_sep_exprs() -> ClosureParser<Vec<MithraVal>> {
    sep_by(inline_expr(), parse_char(','))
}

fn inline_word() -> ClosureParser<String> {
    fn first_non_empty_string(items: &mut Vec<String>) -> String {
        loop {
            match items.pop() {
                Some(word) => {
                    if !word.is_empty() {
                        return word;
                    }
                }
                None => break,
            }
        }
        String::from("")
    }
    combine(
        vec![skip_many(vec![' ']), Box::new(word), skip_many(vec![' '])],
        first_non_empty_string,
    )
}

fn comma_sep_words() -> ClosureParser<Vec<String>> {
    sep_by(inline_word(), parse_char(','))
}

fn parse_function_call(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let function_name = word(text)?;
    skip_spaces()(text)?;
    parse_char('(')(text)?;
    let args = comma_sep_exprs()(text)?;
    parse_char(')')(text).map_err(|_| {
        unterminated_func_call_err(&function_name, text.line_num(), text.inline_position())
    })?;
    Ok(MithraVal::List(vec![
        MithraVal::Atomic(function_name),
        MithraVal::List(args),
    ]))
}

fn parse_list(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    parse_char('[')(text)?;
    let exprs = comma_sep_exprs()(text)?;
    parse_char(']')(text)
        .map_err(|_| unterminated_list_err(text.line_num(), text.inline_position()))?;
    Ok(MithraVal::List(exprs))
}

fn parse_kv_pair_(text: &mut Text) -> Result<(String, MithraVal), MithraError> {
    skip_spaces()(text)?;
    let key = any_string(text)?;
    skip_spaces()(text)?;
    parse_char(':')(text)?;
    skip_spaces()(text)?;
    let value = parse_expr(text)?;
    skip_spaces()(text)?;
    return Ok((key, value));
}

fn run_parser<T: 'static>(parser: FnParser<T>) -> ClosureParser<T> {
    Box::new(move |text: &mut Text| -> Result<T, MithraError> {
        let before_pointer = text.pointer;
        match parser(text) {
            Ok(result) => Ok(result),
            Err(err) => {
                text.pointer = before_pointer;
                return Err(err);
            }
        }
    })
}

fn parse_dict(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();

    //fn parse_kv_pair(text: &mut Text) -> Result<(String, MithraVal), MithraError> {
    //    skip_spaces()(text)?;
    //    let key = any_string(text)?;
    //    skip_spaces()(text)?;
    //    parse_char(':')(text)?;
    //    skip_spaces()(text)?;
    //    let value = parse_expr(text)?;
    //    skip_spaces()(text)?;
    //    return Ok((key, value));
    //}
    let parse_kv_pair = run_parser(parse_kv_pair_);

    parse_char('{')(text)?;
    println!(
        "before pos: {:?}, char: {:?}",
        text.pointer,
        text.get_next()
    );
    let mut kv_pairs = sep_by(Box::new(parse_kv_pair), parse_char(','))(text)?;
    println!("after pos: {:?}, char: {:?}", text.pointer, text.get_next());
    parse_char('}')(text)
        .map_err(|_| unterminated_dictionary_err(text.line_num(), text.inline_position()))?;
    let mut dictionary = BTreeMap::new();
    loop {
        match kv_pairs.pop() {
            Some(kv_pair) => {
                dictionary.insert(kv_pair.0, kv_pair.1);
            }
            None => break,
        }
    }
    Ok(MithraVal::Dict(dictionary))
}

fn first_parse_error_or_default(errors: &Vec<MithraError>) -> Option<MithraError> {
    for error in errors {
        match error {
            MithraError::ParseError(err) => {
                return Some(MithraError::ParseError(err.to_string()));
            }
            _ => {}
        }
    }
    None
}

fn first_text_consumed_or_default(errors: &Vec<MithraError>) -> Option<MithraError> {
    for error in errors {
        match error {
            MithraError::TextConsumed => return Some(MithraError::TextConsumed),
            _ => {}
        }
    }
    None
}

fn select_error(errors: Vec<MithraError>, default: MithraError) -> MithraError {
    match first_parse_error_or_default(&errors) {
        Some(err) => {
            return err;
        }
        None => match first_text_consumed_or_default(&errors) {
            Some(err) => {
                return err;
            }
            None => default,
        },
    }
}

fn parse_expr(text: &mut Text) -> Result<MithraVal, MithraError> {
    let mut errors = Vec::new();
    let parsers: [FnMithraParser; 9] = [
        parse_function_call,
        parse_list,
        parse_dict,
        parse_bool,
        parse_float,
        parse_int,
        parse_null,
        parse_string,
        parse_atom,
    ];
    for parser in &parsers {
        let result = parser(text);
        match result {
            Ok(mithra_val) => {
                return Ok(mithra_val);
            }
            Err(mithra_err) => errors.push(mithra_err),
        }
    }
    Err(select_error(
        errors,
        MithraError::ParseError(format!(
            "couldn't parse an expression (line: {}, char: {}).",
            text.line_num(),
            text.inline_position()
        )),
    ))
}

fn parse_return_statement(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let return_chars = String::from("return").chars().collect();
    let return_parsed = string(return_chars)(text)?;
    skip_spaces()(text)?;
    let expr = parse_expr(text).map_err(|err| match err {
        MithraError::ParseError(msg) => MithraError::ParseError(msg),
        _ => missing_return_expr_err(text.line_num(), text.inline_position()),
    })?;
    Ok(MithraVal::List(vec![
        MithraVal::String(return_parsed),
        expr,
    ]))
}

pub fn parse_assignment(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    let varname = parse_atom(text)?;
    skip_spaces()(text)?;
    parse_char('=')(text)?;
    skip_spaces()(text)?;
    let expr = parse_expr(text)
        .map_err(|_| missing_assignment_expr_err(text.line_num(), text.inline_position()))?;
    Ok(MithraVal::List(vec![
        varname,
        MithraVal::Atomic(String::from("=")),
        expr,
    ]))
}

fn parse_empty_line(text: &mut Text) -> Result<MithraVal, MithraError> {
    text.set_failure_pointer();
    skip_spaces()(text)?;
    parse_char('\n')(text)?;
    Ok(MithraVal::Null)
}

fn parse_indentation(i: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();
        let indent_chars = match i {
            0 => Vec::new(),
            _ => {
                let spaces: String = std::iter::repeat(' ').take(i * 4).collect();
                spaces.chars().collect()
            }
        };
        string(indent_chars)(text)
            .map_err(|_| indentation_err(i, text.line_num(), text.inline_position()))?;
        Ok(MithraVal::Null)
    })
}

fn parse_inline_expr(indent: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();

        println!(
            "position: {:?}, char: {:?}, line_num: {:?}, inline_position: {:?}",
            text.pointer,
            text.get_next(),
            text.line_num(),
            text.inline_position()
        );

        // try parsing empty line first
        if parse_empty_line(text).is_ok() {
            return Ok(MithraVal::Null);
        }
        // parse indentation next
        parse_indentation(indent)(text)?;
        let mut errors = Vec::new();
        // parse multi line expressions
        // (start with more complex, order matters!)
        let closure_parsers: [ClosureMithraParser; 2] =
            [parse_if_else_block(indent), parse_function(indent)];
        for parser in &closure_parsers {
            let result = parser(text);
            match result {
                Ok(mithra_val) => {
                    return Ok(mithra_val);
                }
                Err(mithra_err) => errors.push(mithra_err),
            }
        }
        // parse single line expressions
        let fn_parsers: [FnMithraParser; 3] =
            [parse_return_statement, parse_assignment, parse_expr];
        for parser in &fn_parsers {
            let result = parser(text);
            match result {
                Ok(mithra_val) => {
                    skip_spaces()(text)?;

                    parse_char('\n')(text)?;
                    return Ok(mithra_val);
                }
                Err(mithra_err) => errors.push(mithra_err),
            }
        }
        println!("Errors: {:?}", errors);

        // select first 'ParseError' if there's one
        // select first 'TextCOnsumed' error if there's one
        // if none of the above exists throw generic 'ParseError'
        Err(select_error(
            errors,
            generic_parse_error(text.line_num(), text.inline_position()),
        ))
    })
}

pub fn parse_inline_exprs(indent: usize, error_on_failure: bool) -> ClosureParser<Vec<MithraVal>> {
    Box::new(
        move |text: &mut Text| -> Result<Vec<MithraVal>, MithraError> {
            many(parse_inline_expr(indent), error_on_failure)(text)
        },
    )
}

pub fn parse_if_else_block(indent: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();

        // parse 'if'
        let if_chars = String::from("if").chars().collect();
        string(if_chars)(text)?;
        parse_char(' ')(text)?;
        skip_spaces()(text)?;
        // parse predicate expression
        let predicate = parse_expr(text).map_err(|err| match err {
            MithraError::ParseError(msg) => MithraError::ParseError(msg),
            _ => missing_predicate_expr_err(text.line_num(), text.inline_position()),
        })?;
        skip_spaces()(text)?;
        // parse ':' after predicate expression
        parse_char(':')(text).map_err(|_| {
            missing_colon_after_predicate_expr_err(text.line_num(), text.inline_position())
        })?;
        skip_spaces()(text)?;
        parse_char('\n')(text)?;
        // parse mandatory first 'if' expression
        let first_if_expr = parse_inline_expr(indent + 1)(text).map_err(|err| match err {
            MithraError::ParseError(msg) => MithraError::ParseError(msg),
            _ => missing_mandatory_if_expr_err(text.line_num(), text.inline_position()),
        })?;
        // set up var for storing components of the 'if-else' block
        let mut if_else_block_parsed = vec![MithraVal::Atomic(String::from("if")), predicate];
        // parse rest of expressions in 'if' block
        let tail_if_exprs = parse_inline_exprs(indent + 1, false)(text);
        match tail_if_exprs {
            Ok(mut exprs) => {
                exprs.insert(0, first_if_expr);
                if_else_block_parsed.push(MithraVal::List(exprs));
            }
            Err(_) => {
                if_else_block_parsed.push(MithraVal::List(vec![first_if_expr]));
            }
        }
        // try parsing the indentation of the 'else' branch
        // return everything we parsed so far if we fail
        if parse_indentation(indent)(text).is_err() {
            return Ok(MithraVal::List(if_else_block_parsed));
        }
        // parse 'else:' and return everything we parsed if we fail
        let else_chars = String::from("else").chars().collect();
        let else_parsed = string(else_chars)(text);
        if else_parsed.is_err() {
            return Ok(MithraVal::List(if_else_block_parsed));
        }
        skip_spaces()(text)?;
        parse_char(':')(text)
            .map_err(|_| missing_colon_after_else_err(text.line_num(), text.inline_position()))?;
        if_else_block_parsed.push(MithraVal::Atomic(String::from("else")));
        skip_spaces()(text)?;
        parse_char('\n')(text)?;
        // parse first mandatory 'else' expression
        let first_else_expr = parse_inline_expr(indent + 1)(text).map_err(|err| match err {
            MithraError::ParseError(msg) => MithraError::ParseError(msg),
            _ => missing_mandatory_else_expr_err(text.line_num(), text.inline_position()),
        })?;
        // parse rest of expressions in 'else' block
        let tail_else_exprs = parse_inline_exprs(indent + 1, false)(text);
        match tail_else_exprs {
            Ok(mut exprs) => {
                exprs.insert(0, first_else_expr);
                if_else_block_parsed.push(MithraVal::List(exprs));
            }
            Err(_) => {
                if_else_block_parsed.push(MithraVal::List(vec![first_else_expr]));
            }
        }
        Ok(MithraVal::List(if_else_block_parsed))
    })
}

pub fn parse_function(indent: usize) -> ClosureMithraParser {
    Box::new(move |text: &mut Text| -> Result<MithraVal, MithraError> {
        text.set_failure_pointer();

        // parse 'def'
        let def_chars = String::from("def").chars().collect();
        string(def_chars)(text)?;
        // parse function name
        parse_char(' ')(text)?;
        skip_spaces()(text)?;
        let function_name = word(text)
            .map_err(|_| missing_function_name_err(text.line_num(), text.inline_position()))?;
        skip_spaces()(text)?;
        // parse '('
        parse_char('(')(text).map_err(|_| {
            missing_open_parenthesis_before_func_args_err(text.line_num(), text.inline_position())
        })?;
        // parse args
        let args = comma_sep_words()(text)
            .map_err(|_| missing_function_args_err(text.line_num(), text.inline_position()))?;
        // parse ')'
        parse_char(')')(text).map_err(|_| {
            missing_close_parenthesis_before_func_args_err(text.line_num(), text.inline_position())
        })?;
        // parse ':'
        parse_char(':')(text).map_err(|_| {
            missing_colon_in_function_definition_line_err(text.line_num(), text.inline_position())
        })?;
        skip_spaces()(text)?;
        parse_char('\n')(text)?;
        // parse first mandatory function expression
        let first_expr = parse_inline_expr(indent + 1)(text).map_err(|err| match err {
            MithraError::ParseError(msg) => MithraError::ParseError(msg),
            _ => no_expr_in_function_err(&function_name, text.line_num(), text.inline_position()),
        })?;
        // create container for function expressions
        let mut func_exprs = vec![first_expr];
        // parse function tail expressions
        let tail_exprs = parse_inline_exprs(indent + 1, false)(text);
        match tail_exprs {
            Ok(exprs) => func_exprs.extend(exprs),
            Err(_) => {}
        }
        let function = Function {
            name: function_name,
            params: args,
            body: func_exprs,
        };
        Ok(MithraVal::Function(function))
    })
}
