use std::fmt::Debug;

use crate::data::ClosureParser;
use crate::data::MithraError;
use crate::data::Text;

use crate::errors::unnecessary_sep_char_err;

pub fn combine<T: 'static>(
    parsers: Vec<ClosureParser<T>>,
    selector: fn(&mut Vec<T>) -> T,
) -> ClosureParser<T>
where
    T: Debug,
{
    Box::new(move |text: &mut Text| -> Result<T, MithraError> {
        text.set_failure_pointer();
        let mut results = Vec::new();
        for parser in &parsers {
            let result = parser(text)?;
            results.push(result);
        }
        Ok(selector(&mut results))
    })
}

pub fn sep_by<T1: 'static, T2: 'static>(
    parser: ClosureParser<T1>,
    sep_parser: ClosureParser<T2>,
) -> ClosureParser<Vec<T1>>
where
    T1: Debug,
{
    Box::new(move |text: &mut Text| -> Result<Vec<T1>, MithraError> {
        let mut results = Vec::new();
        let first = parser(text);
        if first.is_err() {
            return Ok(results);
        } else {
            results.push(first.unwrap());
        }
        loop {
            text.set_failure_pointer();
            let sep = sep_parser(text);
            if sep.is_err() {
                break;
            }
            let next = parser(text).map_err(|err| match err {
                MithraError::ParseError(msg) => MithraError::ParseError(msg),
                _ => unnecessary_sep_char_err(text.line_num(), text.inline_position()),
            })?;
            results.push(next);
        }
        return Ok(results);
    })
}

pub fn many<T: 'static>(parser: ClosureParser<T>, error_on_failure: bool) -> ClosureParser<Vec<T>>
where
    T: Debug,
{
    Box::new(move |text: &mut Text| -> Result<Vec<T>, MithraError> {
        let mut results = Vec::new();
        loop {
            match parser(text) {
                Ok(result) => {
                    println!("Many result: {:?}", result);
                    results.push(result);
                }
                Err(MithraError::TextConsumed) => {
                    return Ok(results);
                }
                Err(err) => {
                    if error_on_failure {
                        return Err(err);
                    }
                    return Ok(results);
                }
            }
        }
    })
}
